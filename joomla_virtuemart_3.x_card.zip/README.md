﻿# Расширение Joomla VirtueMart 3.x сервиса «Экспресс Платежи: Интернет-эквайринг»
 Расширение CMS Joomla для интеграции с сервисом «Экспресс Платежи». Расширение позволяет производить прием платежей с помощью банковских карт.
 
 <a href="https://express-pay.by/extensions/virtuemart-3-x/acquiring">Инструкция для установки и настройки</a>
  
 <a href="https://www.youtube.com/c/express-pay-by/videos">Наш Youtube канал с опубликованными видео по расширениям</a>
